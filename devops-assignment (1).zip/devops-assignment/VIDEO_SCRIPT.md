# Video Demonstration Outline (aim for 6-10 minutes)

Record with OBS Studio (free/open-source) or any screen recorder.

## 1. Architecture Overview (~2 min)
- Show the architecture diagram from README.md.
- Explain data flow: sample app exposes /metrics → Prometheus scrapes →
  Prometheus evaluates alert rules → Alertmanager routes by severity →
  Grafana visualizes.
- Explain why this is "service-level": metrics are labeled per business
  service (orders/payments/inventory), tracking request rate, error rate,
  and latency — not just CPU/RAM.

## 2. Dashboard Walkthrough (~2-3 min)
- `docker compose ps` — show all 5 containers running.
- Open Grafana (localhost:3000) → walk through each panel:
  - Request Rate by Service
  - Error Rate % by Service (point out the warning/critical threshold lines)
  - p95 Latency by Service
  - In-Progress Requests
  - Total Errors (5m)
  - Service Up/Down
- Mention refresh is live (5s).

## 3. Alerting & Escalation Demo (~3-4 min)
- Open Prometheus Alerts tab side by side with Grafana.
- Run: `curl http://localhost:5000/simulate-error/payments/10`
  - Show error rate panel climbing in Grafana.
  - Show `HighErrorRate_Warning` go pending → firing in Prometheus.
  - Show it arrive in Alertmanager UI, routed to `team-slack` receiver.
  - (If Slack configured) show the actual Slack message.
- Run: `curl http://localhost:5000/simulate-error/payments/80`
  - Show `HighErrorRate_Critical` fire.
  - Show it routed to `oncall-escalation` (Slack + Email), explain the
    5-minute repeat interval simulating a paging/escalation behavior.
  - Show the inhibition rule suppressing the redundant warning alert.
- Run: `curl http://localhost:5000/simulate-error/payments/2`
  - Show the alert resolving and a "resolved" notification.

## 4. Wrap-up (~30 sec)
- Recap: open-source stack (Prometheus, Grafana OSS, Alertmanager), fully
  reproducible via `docker compose up -d --build`, service-level focus,
  severity-based escalation policy.
- Mention extensibility (Grafana OnCall for formal on-call rotations).
